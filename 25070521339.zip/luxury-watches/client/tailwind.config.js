export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: { navy: '#0b1b33', ink: '#0a0a0a', ivory: '#f7f3ea', cream: '#efe8d8', gold: '#b8975a', charcoal: '#2b2b2b' },
      fontFamily: { serif: ['"Playfair Display"', 'Georgia', 'serif'], sans: ['Inter', 'system-ui', 'sans-serif'] }
    }
  },
  plugins: []
};
