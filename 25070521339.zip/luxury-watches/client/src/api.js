import axios from 'axios';
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || '/api' });
export default api;

export const fmt = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n || 0);
export const PLACEHOLDER = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><rect width="100%" height="100%" fill="#efe8d8"/><circle cx="400" cy="400" r="160" fill="none" stroke="#b8975a" stroke-width="6"/><path d="M400 400V300M400 400l70 40" stroke="#0b1b33" stroke-width="8" stroke-linecap="round"/></svg>'
);
export const onImgError = (e) => { e.currentTarget.onerror = null; e.currentTarget.src = PLACEHOLDER; };
