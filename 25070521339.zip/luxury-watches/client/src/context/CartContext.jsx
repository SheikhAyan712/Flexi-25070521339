import { createContext, useContext, useEffect, useState } from 'react';
const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

const load = () => { try { return JSON.parse(localStorage.getItem('cart')) || []; } catch { return []; } };

export function CartProvider({ children }) {
  const [items, setItems] = useState(load);
  useEffect(() => { try { localStorage.setItem('cart', JSON.stringify(items)); } catch {} }, [items]);

  const add = (w, qty = 1) => setItems((prev) => {
    const max = w.stock || 99;
    const found = prev.find((i) => i._id === w._id);
    if (found) return prev.map((i) => (i._id === w._id ? { ...i, qty: Math.min(i.qty + qty, max) } : i));
    return [...prev, { _id: w._id, name: w.name, brand: w.brand, price: w.price, image: w.images?.[0] || '', stock: max, qty: Math.min(qty, max) }];
  });
  const remove = (id) => setItems((p) => p.filter((i) => i._id !== id));
  const setQty = (id, qty) => setItems((p) => p.map((i) => (i._id === id ? { ...i, qty: Math.max(1, Math.min(qty, i.stock)) } : i)));
  const clear = () => setItems([]);
  const count = items.reduce((s, i) => s + i.qty, 0);
  const total = items.reduce((s, i) => s + i.qty * i.price, 0);

  return <CartContext.Provider value={{ items, add, remove, setQty, clear, count, total }}>{children}</CartContext.Provider>;
}
