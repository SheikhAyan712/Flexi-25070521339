import { Link } from 'react-router-dom';
export default function Footer() {
  return (
    <footer className="bg-ink text-ivory/70 mt-24">
      <div className="max-w-7xl mx-auto px-6 py-16 grid gap-10 md:grid-cols-3">
        <div>
          <p className="font-serif text-ivory text-2xl tracking-[0.2em]">MAISON <span className="text-gold">AURELIA</span></p>
          <p className="mt-4 text-sm leading-relaxed max-w-xs">Purveyors of the world's finest timepieces. Authenticated, insured and delivered with white-glove care.</p>
        </div>
        <div className="text-sm space-y-3">
          <p className="eyebrow">Explore</p>
          <Link to="/shop" className="block hover:text-gold">Collection</Link>
          <Link to="/cart" className="block hover:text-gold">Cart</Link>
          <Link to="/admin" className="block hover:text-gold">Admin</Link>
        </div>
        <div className="text-sm space-y-3">
          <p className="eyebrow">Concierge</p>
          <p>concierge@maisonaurelia.com</p>
          <p>Mon – Sat, 9am – 6pm</p>
        </div>
      </div>
      <div className="border-t border-white/10 py-6 text-center text-xs tracking-widest">© {new Date().getFullYear()} MAISON AURELIA. ALL RIGHTS RESERVED.</div>
    </footer>
  );
}
