import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { fmt, onImgError, PLACEHOLDER } from '../api.js';

export default function WatchCard({ watch, index = 0 }) {
  return (
    <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (index % 3) * 0.08 }}>
      <Link to={`/watch/${watch._id}`} className="group block">
        <div className="relative aspect-square overflow-hidden bg-cream">
          <img src={watch.images?.[0] || PLACEHOLDER} onError={onImgError} alt={watch.name} loading="lazy"
            className="w-full h-full object-cover transition-transform duration-[900ms] group-hover:scale-110" />
          {watch.stock === 0 && <span className="absolute top-3 left-3 bg-ink text-ivory text-[10px] uppercase tracking-widest px-3 py-1">Sold out</span>}
          <div className="absolute inset-x-0 bottom-0 bg-navy/90 text-ivory text-center text-xs uppercase tracking-[0.25em] py-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300">View details</div>
        </div>
        <div className="pt-5 text-center">
          <p className="eyebrow">{watch.brand}</p>
          <h3 className="mt-2 text-lg group-hover:text-gold transition-colors">{watch.name}</h3>
          <p className="mt-1 text-charcoal/80 tracking-wide">{fmt(watch.price)}</p>
        </div>
      </Link>
    </motion.div>
  );
}
