import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FiShoppingBag, FiMenu, FiX } from 'react-icons/fi';
import { useCart } from '../context/CartContext.jsx';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { count } = useCart();
  const link = ({ isActive }) => `text-xs uppercase tracking-[0.25em] transition-colors hover:text-gold ${isActive ? 'text-gold' : 'text-ivory'}`;
  return (
    <header className="sticky top-0 z-50 bg-navy/95 backdrop-blur border-b border-gold/20">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="font-serif text-ivory text-2xl tracking-[0.2em]">MAISON <span className="text-gold">AURELIA</span></Link>
        <nav className="hidden md:flex items-center gap-10">
          <NavLink to="/" end className={link}>Home</NavLink>
          <NavLink to="/shop" className={link}>Collection</NavLink>
          <NavLink to="/admin" className={link}>Admin</NavLink>
        </nav>
        <div className="flex items-center gap-5">
          <Link to="/cart" className="relative text-ivory hover:text-gold transition-colors" aria-label="Cart">
            <FiShoppingBag size={22} />
            {count > 0 && <span className="absolute -top-2 -right-3 bg-gold text-ink text-[10px] font-semibold w-5 h-5 rounded-full flex items-center justify-center">{count}</span>}
          </Link>
          <button className="md:hidden text-ivory" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <FiX size={24} /> : <FiMenu size={24} />}</button>
        </div>
      </div>
      {open && (
        <nav className="md:hidden flex flex-col gap-6 px-6 pb-8 pt-2 bg-navy">
          {[['/', 'Home'], ['/shop', 'Collection'], ['/cart', 'Cart'], ['/admin', 'Admin']].map(([to, l]) => (
            <NavLink key={to} to={to} end={to === '/'} className={link} onClick={() => setOpen(false)}>{l}</NavLink>
          ))}
        </nav>
      )}
    </header>
  );
}
