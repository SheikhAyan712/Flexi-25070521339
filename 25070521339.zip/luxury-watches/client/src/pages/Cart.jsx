import { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiMinus, FiPlus, FiTrash2 } from 'react-icons/fi';
import { useCart } from '../context/CartContext.jsx';
import { fmt, onImgError, PLACEHOLDER } from '../api.js';

export default function Cart() {
  const { items, remove, setQty, clear, total, count } = useCart();
  const [done, setDone] = useState(false);

  if (done) return (
    <div className="py-40 text-center px-6">
      <p className="eyebrow">Thank you</p>
      <h1 className="mt-4 text-4xl">Your order request has been received</h1>
      <p className="mt-4 text-charcoal/70">A concierge will contact you shortly to complete your purchase.</p>
      <Link to="/shop" className="btn btn-navy mt-10">Continue Browsing</Link>
    </div>
  );

  if (items.length === 0) return (
    <div className="py-40 text-center px-6">
      <h1 className="text-4xl">Your cart is empty</h1>
      <p className="mt-4 text-charcoal/70">Discover a timepiece worth treasuring.</p>
      <Link to="/shop" className="btn btn-navy mt-10">Explore Collection</Link>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto px-6 py-16">
      <div className="text-center mb-14"><p className="eyebrow">Shopping Cart</p><h1 className="mt-3 text-4xl md:text-5xl">Your Selection</h1><div className="divider mt-6" /></div>
      <div className="grid lg:grid-cols-[1fr_340px] gap-12">
        <div className="divide-y divide-navy/10 border-y border-navy/10">
          {items.map((i) => (
            <div key={i._id} className="flex gap-5 py-6">
              <Link to={`/watch/${i._id}`} className="w-28 h-28 bg-cream shrink-0 overflow-hidden"><img src={i.image || PLACEHOLDER} onError={onImgError} alt={i.name} className="w-full h-full object-cover" /></Link>
              <div className="flex-1 flex flex-col justify-between">
                <div className="flex justify-between gap-4">
                  <div><p className="eyebrow">{i.brand}</p><Link to={`/watch/${i._id}`} className="font-serif text-lg text-navy hover:text-gold">{i.name}</Link></div>
                  <p className="font-serif text-lg">{fmt(i.price * i.qty)}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center border border-navy/20">
                    <button className="p-2.5 hover:text-gold" onClick={() => setQty(i._id, i.qty - 1)} aria-label="Decrease"><FiMinus size={14} /></button>
                    <span className="w-8 text-center text-sm">{i.qty}</span>
                    <button className="p-2.5 hover:text-gold" onClick={() => setQty(i._id, i.qty + 1)} aria-label="Increase"><FiPlus size={14} /></button>
                  </div>
                  <button onClick={() => remove(i._id)} className="flex items-center gap-2 text-xs uppercase tracking-widest text-charcoal/60 hover:text-red-700"><FiTrash2 /> Remove</button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <aside className="bg-navy text-ivory p-8 h-fit">
          <h2 className="!text-ivory text-2xl">Order Summary</h2>
          <div className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between"><span className="text-ivory/70">Items ({count})</span><span>{fmt(total)}</span></div>
            <div className="flex justify-between"><span className="text-ivory/70">Insured shipping</span><span className="text-gold">Complimentary</span></div>
          </div>
          <div className="flex justify-between border-t border-gold/30 mt-6 pt-6 font-serif text-2xl"><span>Total</span><span className="text-gold">{fmt(total)}</span></div>
          <button onClick={() => { clear(); setDone(true); }} className="btn btn-gold w-full mt-8">Checkout</button>
          <button onClick={clear} className="w-full mt-4 text-xs uppercase tracking-widest text-ivory/60 hover:text-gold">Clear cart</button>
        </aside>
      </div>
    </div>
  );
}
