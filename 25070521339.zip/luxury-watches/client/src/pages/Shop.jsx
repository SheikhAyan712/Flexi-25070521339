import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FiSearch, FiX } from 'react-icons/fi';
import api from '../api.js';
import WatchCard from '../components/WatchCard.jsx';

export default function Shop() {
  const [params] = useSearchParams();
  const [f, setF] = useState({ search: '', brand: params.get('brand') || '', category: '', minPrice: '', maxPrice: '', sort: 'newest', page: 1 });
  const [brands, setBrands] = useState([]);
  const [data, setData] = useState({ watches: [], total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');

  const set = (patch) => setF((p) => ({ ...p, page: 1, ...patch }));

  useEffect(() => { api.get('/watches/meta/brands').then((r) => setBrands(r.data)).catch(() => {}); }, []);
  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      const query = { limit: 9 };
      Object.entries(f).forEach(([k, v]) => { if (v !== '' && v != null) query[k] = v; });
      api.get('/watches', { params: query })
        .then((r) => { setData(r.data); setErr(''); })
        .catch(() => setErr('Unable to load watches. Is the server running?'))
        .finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(t);
  }, [f]);

  const reset = () => setF({ search: '', brand: '', category: '', minPrice: '', maxPrice: '', sort: 'newest', page: 1 });

  return (
    <div className="max-w-7xl mx-auto px-6 py-16">
      <div className="text-center mb-14">
        <p className="eyebrow">The Collection</p>
        <h1 className="mt-4 text-4xl md:text-5xl">All Timepieces</h1>
        <div className="divider mt-6" />
      </div>

      <div className="grid lg:grid-cols-[260px_1fr] gap-12">
        <aside className="space-y-8">
          <div className="relative">
            <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-charcoal/50" />
            <input className="input pl-11" placeholder="Search watches…" value={f.search} onChange={(e) => set({ search: e.target.value })} />
          </div>
          <div>
            <p className="eyebrow mb-3">Brand</p>
            <select className="input" value={f.brand} onChange={(e) => set({ brand: e.target.value })}>
              <option value="">All brands</option>
              {brands.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
          <div>
            <p className="eyebrow mb-3">Category</p>
            <div className="flex flex-wrap gap-2">
              {['', 'Men', 'Women', 'Unisex'].map((c) => (
                <button key={c} onClick={() => set({ category: c })}
                  className={`px-4 py-2 text-xs uppercase tracking-widest border transition-colors ${f.category === c ? 'bg-navy text-ivory border-navy' : 'border-navy/20 hover:border-gold'}`}>{c || 'All'}</button>
              ))}
            </div>
          </div>
          <div>
            <p className="eyebrow mb-3">Price (USD)</p>
            <div className="flex gap-2">
              <input type="number" min="0" className="input" placeholder="Min" value={f.minPrice} onChange={(e) => set({ minPrice: e.target.value })} />
              <input type="number" min="0" className="input" placeholder="Max" value={f.maxPrice} onChange={(e) => set({ maxPrice: e.target.value })} />
            </div>
          </div>
          <button onClick={reset} className="flex items-center gap-2 text-xs uppercase tracking-widest text-charcoal/70 hover:text-gold"><FiX /> Clear filters</button>
        </aside>

        <section>
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8 pb-4 border-b border-navy/10">
            <p className="text-sm text-charcoal/70">{data.total} {data.total === 1 ? 'watch' : 'watches'}</p>
            <select className="input !w-auto" value={f.sort} onChange={(e) => set({ sort: e.target.value })}>
              <option value="newest">Newest</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>

          {err && <p className="text-red-700 text-center py-10">{err}</p>}
          {loading && !err ? (
            <p className="text-center py-24 text-charcoal/60 tracking-widest uppercase text-xs">Loading…</p>
          ) : !err && data.watches.length === 0 ? (
            <p className="text-center py-24 font-serif text-2xl text-navy">No watches match your search.</p>
          ) : (
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-x-8 gap-y-14">
              {data.watches.map((w, i) => <WatchCard key={w._id} watch={w} index={i} />)}
            </div>
          )}

          {data.pages > 1 && (
            <div className="flex justify-center items-center gap-2 mt-16">
              <button disabled={f.page <= 1} onClick={() => setF({ ...f, page: f.page - 1 })} className="px-4 py-2 text-xs uppercase tracking-widest border border-navy/20 disabled:opacity-30 hover:border-gold">Prev</button>
              {Array.from({ length: data.pages }, (_, i) => i + 1).map((n) => (
                <button key={n} onClick={() => setF({ ...f, page: n })} className={`w-10 h-10 text-sm border ${n === f.page ? 'bg-navy text-ivory border-navy' : 'border-navy/20 hover:border-gold'}`}>{n}</button>
              ))}
              <button disabled={f.page >= data.pages} onClick={() => setF({ ...f, page: f.page + 1 })} className="px-4 py-2 text-xs uppercase tracking-widest border border-navy/20 disabled:opacity-30 hover:border-gold">Next</button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
