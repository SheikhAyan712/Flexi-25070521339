import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { FiMinus, FiPlus, FiCheck } from 'react-icons/fi';
import api, { fmt, onImgError, PLACEHOLDER } from '../api.js';
import { useCart } from '../context/CartContext.jsx';
import WatchCard from '../components/WatchCard.jsx';

export default function Product() {
  const { id } = useParams();
  const { add } = useCart();
  const [w, setW] = useState(null);
  const [related, setRelated] = useState([]);
  const [img, setImg] = useState(0);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => {
    setW(null); setImg(0); setQty(1); setErr(''); setRelated([]);
    api.get(`/watches/${id}`).then((r) => {
      setW(r.data);
      api.get('/watches', { params: { brand: r.data.brand, exclude: id, limit: 3 } }).then(async (rel) => {
        let list = rel.data.watches;
        if (list.length < 3) {
          const more = await api.get('/watches', { params: { category: r.data.category, exclude: id, limit: 6 } });
          list = [...list, ...more.data.watches.filter((x) => !list.find((y) => y._id === x._id))].slice(0, 3);
        }
        setRelated(list);
      }).catch(() => {});
    }).catch(() => setErr('Watch not found.'));
  }, [id]);

  if (err) return <div className="py-40 text-center"><h1 className="text-3xl">{err}</h1><Link to="/shop" className="btn btn-navy mt-8">Back to Collection</Link></div>;
  if (!w) return <p className="py-40 text-center text-xs uppercase tracking-widest text-charcoal/60">Loading…</p>;

  const images = w.images?.length ? w.images : [PLACEHOLDER];
  const specs = Object.entries(w.specs || {});
  const inStock = w.stock > 0;

  return (
    <div className="max-w-7xl mx-auto px-6 py-14">
      <p className="text-xs uppercase tracking-widest text-charcoal/60 mb-10"><Link to="/shop" className="hover:text-gold">Collection</Link> / {w.brand} / {w.name}</p>
      <div className="grid md:grid-cols-2 gap-14">
        <div>
          <div className="aspect-square bg-cream overflow-hidden"><img src={images[img]} onError={onImgError} alt={w.name} className="w-full h-full object-cover" /></div>
          {images.length > 1 && (
            <div className="grid grid-cols-5 gap-3 mt-3">
              {images.map((src, i) => (
                <button key={i} onClick={() => setImg(i)} className={`aspect-square overflow-hidden border-2 ${i === img ? 'border-gold' : 'border-transparent opacity-70 hover:opacity-100'}`}>
                  <img src={src} onError={onImgError} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <p className="eyebrow">{w.brand}</p>
          <h1 className="mt-3 text-4xl md:text-5xl leading-tight">{w.name}</h1>
          <p className="mt-5 text-3xl font-serif text-gold">{fmt(w.price)}</p>
          <p className={`mt-4 text-xs uppercase tracking-widest ${inStock ? 'text-green-800' : 'text-red-700'}`}>
            {inStock ? (w.stock <= 3 ? `Only ${w.stock} left in stock` : 'In stock') : 'Out of stock'}
          </p>
          <div className="w-16 h-px bg-gold my-8" />
          <p className="leading-loose text-charcoal/80">{w.description}</p>

          <div className="mt-8">
            <p className="eyebrow mb-3">Key Specifications</p>
            <dl className="divide-y divide-navy/10 border-y border-navy/10 text-sm">
              <div className="flex justify-between py-3"><dt className="text-charcoal/60">Category</dt><dd>{w.category}</dd></div>
              {specs.map(([k, v]) => <div key={k} className="flex justify-between py-3 gap-4"><dt className="text-charcoal/60">{k}</dt><dd className="text-right">{v}</dd></div>)}
            </dl>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <div className="flex items-center border border-navy/20">
              <button className="p-4 hover:text-gold" onClick={() => setQty(Math.max(1, qty - 1))} aria-label="Decrease"><FiMinus /></button>
              <span className="w-10 text-center">{qty}</span>
              <button className="p-4 hover:text-gold" onClick={() => setQty(Math.min(w.stock || 1, qty + 1))} aria-label="Increase"><FiPlus /></button>
            </div>
            <button disabled={!inStock} onClick={() => { add(w, qty); setAdded(true); setTimeout(() => setAdded(false), 2000); }}
              className="btn btn-navy flex-1 disabled:opacity-40 disabled:pointer-events-none">
              {added ? <><FiCheck /> Added to cart</> : 'Add to Cart'}
            </button>
          </div>
          <Link to="/cart" className="inline-block mt-5 text-xs uppercase tracking-widest text-charcoal/70 hover:text-gold">View cart →</Link>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-28">
          <div className="text-center mb-14"><p className="eyebrow">You may also admire</p><h2 className="mt-3 text-3xl md:text-4xl">Related Watches</h2><div className="divider mt-6" /></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">{related.map((r, i) => <WatchCard key={r._id} watch={r} index={i} />)}</div>
        </section>
      )}
    </div>
  );
}
