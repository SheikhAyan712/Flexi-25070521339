import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import api from '../api.js';
import WatchCard from '../components/WatchCard.jsx';

const brands = ['Rolex', 'Patek Philippe', 'Audemars Piguet', 'Omega', 'Cartier', 'Vacheron Constantin', 'Jaeger-LeCoultre'];
const HERO = 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=2000&q=80&auto=format&fit=crop';
const HERITAGE = 'https://images.unsplash.com/photo-1495856458515-0637185db551?w=1400&q=80&auto=format&fit=crop';

export default function Home() {
  const [featured, setFeatured] = useState([]);
  const [err, setErr] = useState('');
  useEffect(() => {
    api.get('/watches', { params: { featured: true, limit: 6 } }).then((r) => setFeatured(r.data.watches)).catch(() => setErr('Unable to load watches. Is the server running?'));
  }, []);

  return (
    <>
      <section className="relative h-[88vh] min-h-[560px] flex items-center justify-center text-center bg-navy overflow-hidden">
        <img src={HERO} alt="" className="absolute inset-0 w-full h-full object-cover opacity-50" onError={(e) => (e.currentTarget.style.display = 'none')} />
        <div className="absolute inset-0 bg-gradient-to-b from-navy/70 via-navy/40 to-navy/90" />
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="relative px-6 max-w-3xl">
          <p className="eyebrow">Fine Horology Since 1952</p>
          <h1 className="mt-6 text-5xl md:text-7xl text-ivory leading-tight">Time, <em className="text-gold">Perfected.</em></h1>
          <p className="mt-6 text-ivory/80 text-lg font-light max-w-xl mx-auto">Discover an exceptional collection of the world's most coveted timepieces, curated for those who value legacy.</p>
          <div className="mt-10 flex flex-wrap gap-4 justify-center">
            <Link to="/shop" className="btn btn-gold">Explore Collection</Link>
            <a href="#heritage" className="btn btn-outline">Our Heritage</a>
          </div>
        </motion.div>
      </section>

      <section className="max-w-7xl mx-auto px-6 pt-28">
        <div className="text-center mb-16">
          <p className="eyebrow">Curated Selection</p>
          <h2 className="mt-4 text-4xl md:text-5xl">Featured Timepieces</h2>
          <div className="divider mt-6" />
        </div>
        {err && <p className="text-center text-red-700">{err}</p>}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-14">
          {featured.map((w, i) => <WatchCard key={w._id} watch={w} index={i} />)}
        </div>
        <div className="text-center mt-16"><Link to="/shop" className="btn btn-navy">View All Watches</Link></div>
      </section>

      <section className="mt-28 bg-navy py-14 overflow-hidden">
        <p className="eyebrow text-center mb-8">The Maisons We Carry</p>
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap justify-center gap-x-14 gap-y-5">
          {brands.map((b) => (
            <Link key={b} to={`/shop?brand=${encodeURIComponent(b)}`} className="font-serif text-xl md:text-2xl text-ivory/70 hover:text-gold transition-colors tracking-wider">{b}</Link>
          ))}
        </div>
      </section>

      <section id="heritage" className="max-w-7xl mx-auto px-6 py-28 grid md:grid-cols-2 gap-16 items-center">
        <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="relative">
          <img src={HERITAGE} alt="Watchmaking heritage" className="w-full aspect-[4/5] object-cover" onError={(e) => (e.currentTarget.style.background = '#efe8d8')} />
          <div className="absolute -bottom-5 -right-5 w-full h-full border border-gold -z-10 hidden md:block" />
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
          <p className="eyebrow">Our Heritage</p>
          <h2 className="mt-4 text-4xl md:text-5xl leading-tight">A legacy measured in generations</h2>
          <div className="w-16 h-px bg-gold my-8" />
          <p className="leading-loose text-charcoal/80">For over seven decades, Maison Aurelia has been a trusted guardian of fine watchmaking. Every piece in our collection is authenticated by master horologists and accompanied by full provenance.</p>
          <p className="mt-4 leading-loose text-charcoal/80">We believe a watch is more than an instrument. It is a story, passed from one wrist to the next.</p>
          <Link to="/shop" className="btn btn-navy mt-10">Discover More</Link>
        </motion.div>
      </section>

      <section className="bg-ink text-center py-24 px-6">
        <h2 className="text-4xl md:text-5xl text-ivory">Find the watch that tells <em className="text-gold">your</em> story</h2>
        <p className="text-ivory/70 mt-5 max-w-lg mx-auto">Complimentary insured shipping and a two-year warranty on every timepiece.</p>
        <Link to="/shop" className="btn btn-gold mt-10">Shop Now</Link>
      </section>
    </>
  );
}
