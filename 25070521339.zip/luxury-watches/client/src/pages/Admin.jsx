import { useEffect, useState } from 'react';
import { FiEdit2, FiTrash2, FiPlus, FiLogOut } from 'react-icons/fi';
import api, { fmt, onImgError, PLACEHOLDER } from '../api.js';

const PASSWORD = 'admin123';
const empty = { name: '', brand: '', price: '', description: '', images: '', category: 'Men', stock: '', featured: false };
const BRANDS = ['Rolex', 'Patek Philippe', 'Audemars Piguet', 'Omega', 'Cartier', 'Vacheron Constantin', 'Jaeger-LeCoultre'];

export default function Admin() {
  const [authed, setAuthed] = useState(sessionStorage.getItem('admin') === '1');
  const [pw, setPw] = useState('');
  const [pwErr, setPwErr] = useState(false);
  const [watches, setWatches] = useState([]);
  const [form, setForm] = useState(null);
  const [editId, setEditId] = useState(null);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  const load = () => api.get('/watches', { params: { limit: 100 } }).then((r) => setWatches(r.data.watches)).catch(() => setErr('Unable to load watches. Is the server running?'));
  useEffect(() => { if (authed) load(); }, [authed]);
  const flash = (m) => { setMsg(m); setTimeout(() => setMsg(''), 2500); };

  const login = (e) => {
    e.preventDefault();
    if (pw === PASSWORD) { sessionStorage.setItem('admin', '1'); setAuthed(true); } else setPwErr(true);
  };

  if (!authed) return (
    <div className="max-w-md mx-auto px-6 py-32 text-center">
      <p className="eyebrow">Restricted</p>
      <h1 className="mt-3 text-4xl">Admin Access</h1>
      <div className="divider mt-6" />
      <form onSubmit={login} className="mt-10 space-y-4">
        <input type="password" className="input" placeholder="Password" value={pw} onChange={(e) => { setPw(e.target.value); setPwErr(false); }} autoFocus />
        {pwErr && <p className="text-red-700 text-sm">Incorrect password.</p>}
        <button className="btn btn-navy w-full">Enter</button>
      </form>
    </div>
  );

  const openNew = () => { setEditId(null); setForm({ ...empty }); window.scrollTo(0, 0); };
  const openEdit = (w) => { setEditId(w._id); setForm({ ...w, images: (w.images || []).join('\n') }); window.scrollTo(0, 0); };
  const change = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async (e) => {
    e.preventDefault();
    const payload = {
      name: form.name, brand: form.brand, description: form.description, category: form.category, featured: !!form.featured,
      price: Number(form.price), stock: Number(form.stock) || 0,
      images: String(form.images).split('\n').map((s) => s.trim()).filter(Boolean)
    };
    try {
      if (editId) await api.put(`/watches/${editId}`, payload); else await api.post('/watches', payload);
      flash(editId ? 'Watch updated' : 'Watch added');
      setForm(null); setErr(''); load();
    } catch (ex) { setErr(ex.response?.data?.message || 'Save failed'); }
  };

  const del = async (w) => {
    if (!window.confirm(`Delete "${w.name}"?`)) return;
    try { await api.delete(`/watches/${w._id}`); flash('Watch deleted'); load(); } catch { setErr('Delete failed'); }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-14">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-10">
        <div><p className="eyebrow">Dashboard</p><h1 className="mt-2 text-4xl">Manage Watches</h1></div>
        <div className="flex gap-3">
          <button onClick={openNew} className="btn btn-navy !py-3"><FiPlus /> Add Watch</button>
          <button onClick={() => { sessionStorage.removeItem('admin'); setAuthed(false); setPw(''); }} className="btn border-navy/30 text-navy hover:border-gold !py-3"><FiLogOut /> Logout</button>
        </div>
      </div>

      {msg && <p className="bg-navy text-ivory px-5 py-3 mb-6 text-sm">{msg}</p>}
      {err && <p className="bg-red-100 text-red-800 px-5 py-3 mb-6 text-sm">{err}</p>}

      {form && (
        <form onSubmit={save} className="bg-white border border-navy/10 p-8 mb-10 grid md:grid-cols-2 gap-5">
          <h2 className="md:col-span-2 text-2xl">{editId ? 'Edit Watch' : 'New Watch'}</h2>
          <input className="input" placeholder="Name *" required value={form.name} onChange={(e) => change('name', e.target.value)} />
          <div>
            <input className="input" placeholder="Brand *" required list="brands" value={form.brand} onChange={(e) => change('brand', e.target.value)} />
            <datalist id="brands">{BRANDS.map((b) => <option key={b} value={b} />)}</datalist>
          </div>
          <input className="input" type="number" min="0" placeholder="Price (USD) *" required value={form.price} onChange={(e) => change('price', e.target.value)} />
          <input className="input" type="number" min="0" placeholder="Stock" value={form.stock} onChange={(e) => change('stock', e.target.value)} />
          <select className="input" value={form.category} onChange={(e) => change('category', e.target.value)}>{['Men', 'Women', 'Unisex'].map((c) => <option key={c}>{c}</option>)}</select>
          <label className="flex items-center gap-3 text-sm"><input type="checkbox" className="w-4 h-4 accent-[#b8975a]" checked={!!form.featured} onChange={(e) => change('featured', e.target.checked)} /> Featured on homepage</label>
          <textarea className="input md:col-span-2" rows="4" placeholder="Description" value={form.description} onChange={(e) => change('description', e.target.value)} />
          <textarea className="input md:col-span-2" rows="4" placeholder="Image URLs (one per line)" value={form.images} onChange={(e) => change('images', e.target.value)} />
          <div className="md:col-span-2 flex gap-3">
            <button className="btn btn-navy">{editId ? 'Save Changes' : 'Create Watch'}</button>
            <button type="button" onClick={() => setForm(null)} className="btn border-navy/30 text-navy hover:border-gold">Cancel</button>
          </div>
        </form>
      )}

      <div className="overflow-x-auto bg-white border border-navy/10">
        <table className="w-full text-sm text-left">
          <thead className="bg-navy text-ivory text-xs uppercase tracking-widest">
            <tr><th className="p-4">Image</th><th className="p-4">Name</th><th className="p-4">Brand</th><th className="p-4">Category</th><th className="p-4">Price</th><th className="p-4">Stock</th><th className="p-4">Featured</th><th className="p-4 text-right">Actions</th></tr>
          </thead>
          <tbody className="divide-y divide-navy/10">
            {watches.map((w) => (
              <tr key={w._id} className="hover:bg-ivory/60">
                <td className="p-4"><img src={w.images?.[0] || PLACEHOLDER} onError={onImgError} alt="" className="w-14 h-14 object-cover" /></td>
                <td className="p-4 font-medium">{w.name}</td>
                <td className="p-4">{w.brand}</td>
                <td className="p-4">{w.category}</td>
                <td className="p-4">{fmt(w.price)}</td>
                <td className="p-4">{w.stock}</td>
                <td className="p-4">{w.featured ? 'Yes' : '—'}</td>
                <td className="p-4 text-right whitespace-nowrap">
                  <button onClick={() => openEdit(w)} className="p-2 hover:text-gold" aria-label="Edit"><FiEdit2 /></button>
                  <button onClick={() => del(w)} className="p-2 hover:text-red-700" aria-label="Delete"><FiTrash2 /></button>
                </td>
              </tr>
            ))}
            {watches.length === 0 && <tr><td colSpan="8" className="p-10 text-center text-charcoal/60">No watches yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
