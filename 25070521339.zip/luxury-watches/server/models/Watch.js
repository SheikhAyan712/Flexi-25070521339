const mongoose = require('mongoose');
const watchSchema = new mongoose.Schema({
  name: { type: String, required: [true, 'Name is required'], trim: true },
  brand: { type: String, required: [true, 'Brand is required'], trim: true },
  price: { type: Number, required: [true, 'Price is required'], min: 0 },
  description: { type: String, default: '' },
  images: { type: [String], default: [] },
  category: { type: String, enum: ['Men', 'Women', 'Unisex'], default: 'Unisex' },
  stock: { type: Number, default: 0, min: 0 },
  featured: { type: Boolean, default: false },
  specs: { type: Map, of: String, default: {} },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Watch', watchSchema);
