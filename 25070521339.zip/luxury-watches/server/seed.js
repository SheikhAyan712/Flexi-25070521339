const Watch = require('./models/Watch');
const U = (id) => `https://images.unsplash.com/${id}?w=1200&q=80&auto=format&fit=crop`;
const P = {
  a: 'photo-1523170335258-f5ed11844a49', b: 'photo-1587836374828-4dbafa94cf0e', c: 'photo-1524592094714-0f0654e20314',
  d: 'photo-1547996160-81dfa63595aa', e: 'photo-1522312346375-d1a52e2b99b3', f: 'photo-1539874754764-5a96559165b0',
  g: 'photo-1508057198894-247b23fe5ade', h: 'photo-1533139502658-0198f920d8e8', i: 'photo-1614164185128-e4ec99c436d7',
  j: 'photo-1495856458515-0637185db551', k: 'photo-1542496658-e33a6d0d50f6', l: 'photo-1509048191080-d2984bad6ae5'
};
const imgs = (...k) => k.map((x) => U(P[x]));
const data = [
  { name: 'Submariner Date', brand: 'Rolex', price: 14500, category: 'Men', stock: 4, featured: true, images: imgs('a', 'b', 'c'),
    description: 'The reference among divers\' watches. Oystercoat case in Oystersteel, unidirectional bezel with Cerachrom insert and a luminescent display, waterproof to 300 metres.',
    specs: { Movement: 'Automatic, Cal. 3235', Case: '41 mm Oystersteel', 'Water resistance': '300 m', 'Power reserve': '70 hours' } },
  { name: 'Nautilus 5711', brand: 'Patek Philippe', price: 118000, category: 'Men', stock: 1, featured: true, images: imgs('d', 'e', 'f'),
    description: 'An icon of the luxury sports watch, with a distinctive porthole-inspired case and horizontally embossed dial in a sleek, elegant silhouette.',
    specs: { Movement: 'Automatic, Cal. 26-330 S C', Case: '40 mm Steel', 'Water resistance': '120 m', 'Power reserve': '45 hours' } },
  { name: 'Royal Oak Selfwinding', brand: 'Audemars Piguet', price: 54500, category: 'Unisex', stock: 2, featured: true, images: imgs('e', 'g', 'h'),
    description: 'The octagonal bezel with eight hexagonal screws and the Grande Tapisserie dial define this landmark of haute horlogerie.',
    specs: { Movement: 'Automatic, Cal. 4302', Case: '41 mm Stainless steel', 'Water resistance': '50 m', 'Power reserve': '70 hours' } },
  { name: 'Speedmaster Moonwatch', brand: 'Omega', price: 7300, category: 'Men', stock: 8, featured: true, images: imgs('c', 'i', 'a'),
    description: 'The legendary chronograph worn on the Moon. Hand-wound Co-Axial movement, Hesalite crystal and black dial with tachymeter bezel.',
    specs: { Movement: 'Manual, Cal. 3861', Case: '42 mm Steel', 'Water resistance': '50 m', 'Power reserve': '50 hours' } },
  { name: 'Tank Louis Cartier', brand: 'Cartier', price: 9250, category: 'Women', stock: 5, featured: true, images: imgs('j', 'k', 'l'),
    description: 'Timeless rectangular elegance since 1917. Roman numeral dial, blued-steel sword-shaped hands and a sapphire cabochon crown.',
    specs: { Movement: 'Manual, Cal. 430 MC', Case: '33.7 x 25.5 mm 18K Gold', 'Water resistance': '30 m', Strap: 'Alligator leather' } },
  { name: 'Overseas Perpetual Calendar', brand: 'Vacheron Constantin', price: 89000, category: 'Men', stock: 2, featured: true, images: imgs('f', 'h', 'd'),
    description: 'A refined perpetual calendar with an integrated bracelet and quick-change strap system, built for the modern traveller.',
    specs: { Movement: 'Automatic, Cal. 1120 QP/1', Case: '41.5 mm Steel', 'Water resistance': '150 m', 'Power reserve': '40 hours' } },
  { name: 'Reverso Classic', brand: 'Jaeger-LeCoultre', price: 8900, category: 'Unisex', stock: 6, featured: false, images: imgs('l', 'j', 'k'),
    description: 'The iconic Art Deco swivelling case, born in 1931 to withstand polo matches. Silvered sunray dial with baton hands.',
    specs: { Movement: 'Manual, Cal. 822/2', Case: '45.5 x 27.4 mm Steel', 'Water resistance': '30 m', 'Power reserve': '42 hours' } },
  { name: 'Datejust 31 Rose Gold', brand: 'Rolex', price: 23500, category: 'Women', stock: 3, featured: false, images: imgs('k', 'e', 'b'),
    description: 'A classic of feminine refinement in 18 ct Everose gold with a fluted bezel and a Jubilee bracelet.',
    specs: { Movement: 'Automatic, Cal. 2236', Case: '31 mm Everose gold', 'Water resistance': '100 m', 'Power reserve': '55 hours' } },
  { name: 'Seamaster Diver 300M', brand: 'Omega', price: 5600, category: 'Men', stock: 10, featured: false, images: imgs('b', 'a', 'g'),
    description: 'Ceramic bezel, laser-engraved wave dial and a Master Chronometer movement certified to 15,000 gauss.',
    specs: { Movement: 'Automatic, Cal. 8800', Case: '42 mm Steel', 'Water resistance': '300 m', 'Power reserve': '55 hours' } },
  { name: 'Calatrava 6119G', brand: 'Patek Philippe', price: 36500, category: 'Unisex', stock: 2, featured: false, images: imgs('i', 'c', 'j'),
    description: 'The purest expression of the round dress watch: white gold case, hobnail-pattern bezel and a charcoal grey dial.',
    specs: { Movement: 'Manual, Cal. 30-255 PS', Case: '39 mm White gold', 'Water resistance': '30 m', 'Power reserve': '65 hours' } },
  { name: 'Santos de Cartier', brand: 'Cartier', price: 8100, category: 'Unisex', stock: 7, featured: false, images: imgs('g', 'l', 'f'),
    description: 'Aviation heritage made wearable: square bezel with exposed screws and QuickSwitch interchangeable bracelet.',
    specs: { Movement: 'Automatic, Cal. 1847 MC', Case: '39.8 mm Steel', 'Water resistance': '100 m', 'Power reserve': '40 hours' } },
  { name: 'Royal Oak Offshore Chronograph', brand: 'Audemars Piguet', price: 41800, category: 'Men', stock: 0, featured: false, images: imgs('h', 'd', 'a'),
    description: 'The bold "Beast": a 43 mm chronograph with a Méga Tapisserie dial and a rubber-clad bezel.',
    specs: { Movement: 'Automatic, Cal. 4401', Case: '43 mm Steel', 'Water resistance': '100 m', 'Power reserve': '70 hours' } }
];
module.exports = async function seed() {
  if ((await Watch.countDocuments()) === 0) {
    const t = Date.now();
    await Watch.insertMany(data.map((w, i) => ({ ...w, createdAt: new Date(t - i * 86400000) })));
    console.log(`Seeded ${data.length} watches`);
  }
};
