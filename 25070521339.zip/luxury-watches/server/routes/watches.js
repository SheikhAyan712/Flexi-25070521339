const express = require('express');
const Watch = require('../models/Watch');
const router = express.Router();
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

router.get('/meta/brands', async (req, res, next) => {
  try { res.json((await Watch.distinct('brand')).sort()); } catch (e) { next(e); }
});

router.get('/', async (req, res, next) => {
  try {
    const { search, brand, category, minPrice, maxPrice, sort, featured, exclude } = req.query;
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 9, 1), 100);
    const q = {};
    if (search) { const r = new RegExp(esc(search), 'i'); q.$or = [{ name: r }, { brand: r }, { description: r }]; }
    if (brand) q.brand = brand;
    if (category) q.category = category;
    if (featured === 'true') q.featured = true;
    if (exclude) q._id = { $ne: exclude };
    if (minPrice || maxPrice) {
      q.price = {};
      if (minPrice) q.price.$gte = Number(minPrice);
      if (maxPrice) q.price.$lte = Number(maxPrice);
    }
    const sorts = { price_asc: { price: 1 }, price_desc: { price: -1 }, newest: { createdAt: -1 } };
    const total = await Watch.countDocuments(q);
    const watches = await Watch.find(q).sort(sorts[sort] || sorts.newest).skip((page - 1) * limit).limit(limit);
    res.json({ watches, total, page, pages: Math.max(Math.ceil(total / limit), 1) });
  } catch (e) { next(e); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const w = await Watch.findById(req.params.id);
    if (!w) return res.status(404).json({ message: 'Watch not found' });
    res.json(w);
  } catch (e) { next(e); }
});
router.post('/', async (req, res, next) => {
  try { res.status(201).json(await Watch.create(req.body)); } catch (e) { next(e); }
});
router.put('/:id', async (req, res, next) => {
  try {
    const w = await Watch.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!w) return res.status(404).json({ message: 'Watch not found' });
    res.json(w);
  } catch (e) { next(e); }
});
router.delete('/:id', async (req, res, next) => {
  try {
    const w = await Watch.findByIdAndDelete(req.params.id);
    if (!w) return res.status(404).json({ message: 'Watch not found' });
    res.json({ message: 'Watch deleted' });
  } catch (e) { next(e); }
});
module.exports = router;
