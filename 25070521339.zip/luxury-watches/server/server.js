require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const mongoose = require('mongoose');
const seed = require('./seed');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(morgan('dev'));

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/watches', require('./routes/watches'));

app.use((req, res) => res.status(404).json({ message: 'Route not found' }));
app.use((err, req, res, next) => {
  if (err.name === 'ValidationError') return res.status(400).json({ message: Object.values(err.errors).map((e) => e.message).join(', ') });
  if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid ID' });
  console.error(err);
  res.status(500).json({ message: 'Server error' });
});

const PORT = process.env.PORT || 5000;
if (!process.env.MONGO_URI) { console.error('Missing MONGO_URI in server/.env'); process.exit(1); }
mongoose.connect(process.env.MONGO_URI)
  .then(async () => { console.log('MongoDB connected'); await seed(); app.listen(PORT, () => console.log(`API running on port ${PORT}`)); })
  .catch((e) => { console.error('MongoDB connection failed:', e.message); process.exit(1); });
