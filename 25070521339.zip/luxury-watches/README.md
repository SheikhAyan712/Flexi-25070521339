# Maison Aurelia — Luxury Watches (MERN)

## Setup
1. **Backend**
   ```bash
   cd server
   npm install
   ```
   Create `server/.env`:
   ```
   MONGO_URI=your_mongodb_atlas_connection_string
   PORT=5000
   ```
   ```bash
   npm start
   ```
   The database seeds 12 watches automatically when empty.
2. **Frontend** (new terminal)
   ```bash
   cd client
   npm install
   npm run dev
   ```
   Open http://localhost:5173 (Vite proxies `/api` to port 5000).
3. **Admin:** http://localhost:5173/admin — password `admin123` (demo only).

Optional: set `VITE_API_URL` in `client/.env` if your API is hosted elsewhere (e.g. `https://api.example.com/api`).
